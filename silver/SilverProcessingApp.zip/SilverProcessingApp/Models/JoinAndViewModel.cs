﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SilverProcessingApp.Models
{
    public class JoinAndViewModel
    {
        public ScrapSilverPurityConvertorJob PCon { get; set; }
        public ScrapSilverPurityCalculatorJobDetails PCal { get; set; }

    }
}
